#!/bin/bash
echo "Hola, este script es público, mi nombre es $nombreEstudiante ."
