#bin/bash
echo "Script compartido para el grupo teamWork"
