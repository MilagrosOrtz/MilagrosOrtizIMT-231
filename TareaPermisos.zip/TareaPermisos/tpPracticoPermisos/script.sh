#bin/bash
echo "Ingresa tu nombre"
read nombre
echo "Hola,$nombre"
cat script.sh
