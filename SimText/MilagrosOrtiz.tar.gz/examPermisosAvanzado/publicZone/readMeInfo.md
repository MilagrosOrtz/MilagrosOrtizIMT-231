contiene información acerca de otros archivos en un directorio. Es una forma de documentación de software, usualmente en un archivo de texto plano llamado READ.ME
